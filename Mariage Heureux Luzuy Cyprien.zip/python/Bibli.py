def fonctionImportationTest(messageDeRetour):
    print(messageDeRetour, ": bien reçu")
    return ("importation réussie")